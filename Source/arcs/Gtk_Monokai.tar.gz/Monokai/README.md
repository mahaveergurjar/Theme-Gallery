# Monokai-gtk
A gtk theme using the Monokai dark colour scheme based on Numix theme and built using oomox

## Screenshot
![screenshot](/screenshot.png?raw=true)

## Install
To install clone this repository into your theme folder
